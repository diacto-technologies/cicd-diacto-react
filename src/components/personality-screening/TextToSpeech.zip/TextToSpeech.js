import React, { useState, useEffect } from "react";


const TextToSpeech = ({ text, isSpeaking, setIsSpeaking }) => {
    const [isPaused, setIsPaused] = useState(false);
    const [utterance, setUtterance] = useState(null);
    const [voice, setVoice] = useState(null);
    const [pitch, setPitch] = useState(1.8);
    const [rate, setRate] = useState(1);
    const [volume, setVolume] = useState(1);
    const [voices, setVoices] = useState([]);


    // useEffect(() => {
    //     const synth = window.speechSynthesis;
    //     let voiceList = synth.getVoices();
    //     setVoices(voiceList)
    // },[])

    useEffect(() => {
        if (text) {
            const synth = window.speechSynthesis;
            const u = new SpeechSynthesisUtterance(text);
            let voiceList;
            console.log(voices)
            if (!voices?.length) {
                voiceList = synth.getVoices();
                console.log(voiceList)
                setVoices(voiceList)
            }
            else {
                setUtterance(u);
                setVoice(voices[6]);
                setIsSpeaking(true);

                u.voice =  voices[6];
                u.lang = "en-US";
                // u.pitch = pitch;
                u.rate = rate;
                u.volume = volume;

                const handleEnd = () => {
                    setIsSpeaking(false); // Set speaking to false when speaking is done
                };

                u.onend = handleEnd;


                synth.speak(u);
            }

            return () => {
                synth.cancel();
                setIsSpeaking(false);
            };
        }
    }, [text,voices]);




    // const handlePlay = () => {
    //     const synth = window.speechSynthesis;

    //     if (isPaused) {
    //         synth.resume();
    //     } else {
    //         setIsSpeaking(true);
    //         utterance.voice = voice;

    //         utterance.pitch = pitch;
    //         utterance.rate = rate;
    //         utterance.volume = volume;
    //         synth.speak(utterance);


    //     }

    //     setIsPaused(false);
    // };

    // const handlePause = () => {
    //     const synth = window.speechSynthesis;
    //     synth.pause();
    //     setIsPaused(true);
    // };

    // const handleStop = () => {
    //     const synth = window.speechSynthesis;

    //     synth.cancel();

    //     setIsPaused(false);
    // };

    // const handleVoiceChange = (event) => {
    //     const voices = window.speechSynthesis.getVoices();
    //     setVoice(voices.find((v) => v.name === event.target.value));
    // };

    // const handlePitchChange = (event) => {
    //     setPitch(parseFloat(event.target.value));
    // };

    // const handleRateChange = (event) => {
    //     setRate(parseFloat(event.target.value));
    // };

    // const handleVolumeChange = (event) => {
    //     setVolume(parseFloat(event.target.value));
    // };


    return (
        <div className="flex space-x-4 items-center text-sm">
            {/* <label>
                Voice:
                <select value={voice?.name} onChange={handleVoiceChange}>
                    {window.speechSynthesis.getVoices().map((voice) => (
                        <option key={voice.name} value={voice.name}>
                            {voice.name}
                        </option>
                    ))}
                </select>
            </label> */}



            {/* <div className="flex items-center gap-x-3">
                <label >
                    Pitch:

                </label>
                <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.1"
                    value={pitch}
                    onChange={handlePitchChange}
                />
            </div> */}


            {/* <label>
                Speed:
                <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.1"
                    value={rate}
                    onChange={handleRateChange}
                />
            </label>
            <br /> */}
            {/* <div className="flex items-center gap-x-3">
                <label >Volume:</label>
                <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={volume}
                    onChange={handleVolumeChange}
                />
            </div> */}

            {/* <button className="px-2 py-1.5 rounded-md bg-indigo-500 shadow-sm text-white" onClick={handlePlay}>{isPaused ? "Resume" : "Play Again"}</button> */}
            {/* {isSpeaking && audioContext && <WaveformVisualization audioContext={audioContext}/>} */}
            {/* <button onClick={handlePause}>Pause</button> */}
            {/* <button onClick={handleStop}>Stop</button> */}
        </div>
    );
};

export default TextToSpeech;